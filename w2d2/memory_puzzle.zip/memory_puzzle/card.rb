
class Card 
    attr_accessor :face_up
    attr_reader :face_value

    def initialize(value) 
      @face_value = value
      @face_up = false 
    end

    # def hide
    #     @face_up = false
    # end

    # def reveal pos 
    #  # @face_up
    #   [pos]= 
    # end
  

end

# rather than passing in initialize we should set an arr with potential values and return a random value
