require_relative "./card.rb"
require_relative "./game.rb"
require "byebug"
class Board 

  @@values = {W: 2, X: 2, Q: 2, A: 2, Y: 2, P: 2, S: 2, N: 2 } 
   
  def initialize 
    @grid = Array.new(4) { Array.new(4)}
    
  end

  def random_card
     potential_card = @@values.keys.sample
     if @@values[potential_card] > 0 
      @@values[potential_card] -= 1
      return potential_card 
     else 
      random_card 
     end
  end

  def []= pos, value 
    row, col = pos 
    @grid[row][col] = value 
  end

  def populate
    length = @grid[0].length 
    (0...length).each do |s1|
      (0...length).each do |s2|
        card = Card.new(random_card)
        position = [s1,s2]
        value = card 
        self[position]= value    
      end
    end
  end

  def render 
    board = @grid.map do |row| 
      row.map do |el| 
        if el.face_up  
          el.face_value   
        else  
          "_"
        end
      end
    end

    p "0 1 2 3" 
      
    board.each_with_index do |row,idx|
      row_string = row.join(" ") 
      p "#{row} #{row_string}"
    end     
  end
end

  # p "0 1 2 3" render logic 
    # (0..3).each do |row| 
    #   i = 0
    #   positions = []
    #   line_print = ""
    #   while i < 3
    #     debugger
    #     line_print += row.to_s
    #     positions << @grid[row][i]
    #     p positions
    #     i += 1
    #   end 

      # positions.each do |card| 
      #   if card.face_up == true 
      #     line_print += card.face_value 
      #   else
      #     line_print += " "
      #   end 
      # end
      # p line_print 