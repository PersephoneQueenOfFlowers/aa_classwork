class CommentsController < ApplicationController
  # def index
  #     @blogs = Blog.all
  #     render :index
  # end

    def show
      @comment = Comment.find(params[:id])
      render comment_url 
    end

    def create 
      @comment = Comment.create(comment_params)

      if @comment.save 
        redirect_to comment_url(@comment)  
      else
        render :show 
      end
    end

    def destroy 
      comment = Comment.find_by(comment_params)
      comment.destroy 
      redirect_to :index 
    end


    private
    def comment_params
        params.require(:comment).permit(:body, :author_id, :commment_id)
    end
end